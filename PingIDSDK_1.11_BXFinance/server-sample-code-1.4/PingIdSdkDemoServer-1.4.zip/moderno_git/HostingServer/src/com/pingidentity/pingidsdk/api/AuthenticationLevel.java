package com.pingidentity.pingidsdk.api;

/**
 * AuthenticationLevel
 *
 * Created by Ping Identity on 3/23/17.
 * Copyright © 2017 Ping Identity. All rights reserved.
 */
public enum AuthenticationLevel {
	NONE, MOBILE_PAYLOAD, OTP, PUSH;
}
